import requests as req
import re
import pandas as pd
from bs4 import BeautifulSoup 
import numpy as np

url = r"https://www.flipkart.com/furniture/beds-more/pr?sid=wwe%2C7p7&otracker[]=nmenu_sub_Home%20%26%20Furniture_0_Beds&otracker[]=nmenu_sub_Home%20%26%20Furniture_0_Beds"
URL = r"https://www.flipkart.com/furniture/beds-more/pr?sid=wwe%2C7p7&otracker%5B%5D=nmenu_sub_Home+%26+Furniture_0_Beds&otracker%5B%5D=nmenu_sub_Home+%26+Furniture_0_Beds&page="

content = req.get(url).text
soup = BeautifulSoup(content,'html.parser') 

res = soup.find(text=re.compile("Page 1 of (.*)"))
total_page = res.split()[-1]
# print(total_page)                                                                                #74        
               
product = []
rating = []
price = []
offer = []
for i in range(1,int(total_page)+1):
    url1 = URL + str(i)
    # print(url1)

    content1 = req.get(url1).text
    soup1 = BeautifulSoup(content1,'html.parser')

    for link1 in soup1.find_all('div',class_="_75nlfW"):
        for link2 in link1.find_all('div',class_="slAVV4"):
            for link3 in link2.find_all('a',class_='wjcEIp'):
                prod = link3.text
                # print(prod)
                product.append(prod)
                    
                if link2.find_all('div',class_='_5OesEi afFzxY'):
                    for B in link2.find_all('div',class_='XQDdHH'):
                        rate = B.text
                        rating.append(rate)
                else:
                    rating.append('Rating Not Given / Found')

                if link2.find_all('div',class_='hl05eU'):
                    for C in link2.find_all('div',class_='Nx9bqj'):
                        prc = C.text
                        price.append(prc)
                else:
                    price.append('Price Not Given / Found')

                if link2.find_all('div',class_='hl05eU'):
                    for D in link2.find_all('div',class_='UkUFwK'):
                        off = D.text
                        offer.append(off)
                else:
                    offer.append('Offer Not Given / Found')

data1 = pd.DataFrame([product, rating, price, offer], index = ('Product Name','Product rating', 'Product price', 'offer'))
df = data1.transpose()
print(df)

df.to_csv("Product.csv",index=False)

df.to_excel("Product.xlsx",index=False)


